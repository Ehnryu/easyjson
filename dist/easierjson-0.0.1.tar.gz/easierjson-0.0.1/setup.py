from setuptools import setup

setup(name='easierjson',
      version='0.0.1',
      description='A way to use JSON efficiently and properly',
      url='http://github.com/Ehnryu/easyjson',
      author='Ehnryu/Sakurai07',
      author_email='blzzardst0rm@gmail.com',
      license='MIT',
      packages=['easyjson'],
    keywords=['easjson', 'fast',"json"])